/* eslint-disable  func-names */
/* eslint quote-props: ["error", "consistent"]*/
module.exports = {
    RECIPES_EN_GB: {
        'navigate back': 'navigating back',
        'open facebook': 'loading facebook',
        'open youtube' : 'loading youtube',
        'scroll down': 'scrolling down',
        'scroll up': 'scrolling up',
        'enter': 'enter pressed',
        'spacebar': 'spacebar pressed',
    }
};
    